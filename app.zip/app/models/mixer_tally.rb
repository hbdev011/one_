class MixerTally < ActiveRecord::Base
	belongs_to :system
end
