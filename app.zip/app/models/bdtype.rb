class Bdtype < ActiveRecord::Base
end
