class SystemMatching < ActiveRecord::Base
end
