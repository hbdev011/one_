class SystemAssoziation < ActiveRecord::Base
end
