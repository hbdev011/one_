class PanelFunction < ActiveRecord::Base
end
