class Frame < ActiveRecord::Base
  
  belongs_to :system
  
  
end
