class Panel < ActiveRecord::Base
end
