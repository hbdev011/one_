class FamilyPanel < ActiveRecord::Base
end
