# Bediengerät
class Bg < ActiveRecord::Base

end
