class Tally < ActiveRecord::Base
	belongs_to :system
	belongs_to :kreuzschiene
end
