class Bme < ActiveRecord::Base
  
  belongs_to :source
  
end
