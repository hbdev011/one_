class PanelsController < ApplicationController
end
