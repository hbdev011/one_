module PanelsHelper
end
